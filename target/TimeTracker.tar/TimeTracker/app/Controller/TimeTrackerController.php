<?php
App::uses('AppController', 'Controller');

class TimeTrackerController extends AppController {
// app/Controller/AppController.php
   //...
    public $name = 'TimeTracker';

    public function home(){
    }
}
