<?php
class Company extends AppModel {
  public $primaryKey = 'company_id';
}
?>